"""Wine Quality Prediction - Flask backend.

Loads the Random Forest and Decision Tree models that were trained in Google
Colab (they are used exactly as exported; nothing is retrained here).
"""
import io
import json
import os
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request

BASE_DIR = Path(__file__).resolve().parent
MODELS_DIR = BASE_DIR / "models"
DATASET_PATH = BASE_DIR / "dataset" / "winequality-red-project.csv"

RF_MODEL_PATH = MODELS_DIR / "random_forest_model.pkl"
DT_MODEL_PATH = MODELS_DIR / "decision_tree_model.pkl"
METADATA_PATH = MODELS_DIR / "model_metadata.json"

EXPECTED_FEATURES = [
    "fixed acidity",
    "volatile acidity",
    "citric acid",
    "residual sugar",
    "chlorides",
    "free sulfur dioxide",
    "total sulfur dioxide",
    "density",
    "pH",
    "sulphates",
    "alcohol",
]

# Plain-language help text and units shown next to each input.
FEATURE_INFO = {
    "fixed acidity": ("g/L", "Non-volatile acids (mostly tartaric). They give the wine its tart, crisp backbone."),
    "volatile acidity": ("g/L", "Acetic acid. In high amounts it gives an unpleasant vinegar-like smell and taste."),
    "citric acid": ("g/L", "A small amount adds freshness and a citrusy lift to the flavour."),
    "residual sugar": ("g/L", "Sugar left after fermentation. Higher values taste sweeter."),
    "chlorides": ("g/L", "Salt content of the wine."),
    "free sulfur dioxide": ("mg/L", "SO2 that is still active and protects the wine from oxidation and microbes."),
    "total sulfur dioxide": ("mg/L", "Free plus bound SO2. Very high levels can be noticeable in smell and taste."),
    "density": ("g/cm3", "How heavy the wine is compared with water; depends mainly on alcohol and sugar."),
    "pH": ("", "Acidity scale. Lower pH means a more acidic, sharper wine."),
    "sulphates": ("g/L", "A wine additive that acts as an antimicrobial and antioxidant."),
    "alcohol": ("% vol", "Alcohol by volume. Adds body and warmth."),
}

GOOD_THRESHOLD = 6          # predicted quality >= 6 -> "Good"
MAX_QUALITY_SCALE = 10      # quality is scored out of 10
MAX_CSV_ROWS = 5000


def load_artifacts():
    if not RF_MODEL_PATH.exists():
        raise FileNotFoundError(f"Random Forest model not found at {RF_MODEL_PATH}")
    if not DT_MODEL_PATH.exists():
        raise FileNotFoundError(f"Decision Tree model not found at {DT_MODEL_PATH}")
    with open(METADATA_PATH, "r", encoding="utf-8") as f:
        metadata = json.load(f)
    if metadata.get("features") != EXPECTED_FEATURES:
        raise ValueError("model_metadata.json features do not match the expected 11 features/order.")
    rf = joblib.load(RF_MODEL_PATH)
    dt = joblib.load(DT_MODEL_PATH)
    if getattr(rf, "n_features_in_", None) != len(EXPECTED_FEATURES):
        raise ValueError("Random Forest model does not expect 11 input features.")
    return rf, dt, metadata


def load_ranges():
    """Min / median / max of each feature in the model training dataset."""
    df = pd.read_csv(DATASET_PATH)
    ranges = {}
    for feat in EXPECTED_FEATURES:
        col = df[feat]
        ranges[feat] = {
            "min": float(col.min()),
            "max": float(col.max()),
            "median": float(col.median()),
        }
    return ranges, int(len(df))


rf_model, dt_model, METADATA = load_artifacts()
RANGES, DATASET_ROWS = load_ranges()

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024  # 2 MB upload limit


def quality_percentage(score):
    return round(float(score) / MAX_QUALITY_SCALE * 100, 1)


def category(score):
    return "Good" if score >= GOOD_THRESHOLD else "Needs Improvement"


def predict_frame(df):
    """Run both models on a DataFrame having the 11 features in order."""
    X = df[EXPECTED_FEATURES]
    rf_pred = rf_model.predict(X)
    rf_conf = rf_model.predict_proba(X).max(axis=1)
    dt_pred = dt_model.predict(X)
    return rf_pred, rf_conf, dt_pred


def range_warnings(values):
    out = []
    for feat, v in values.items():
        r = RANGES[feat]
        if v < r["min"] or v > r["max"]:
            out.append(f"{feat} ({v:g}) is outside the model training dataset range "
                       f"({r['min']:g} to {r['max']:g}); the prediction may be less reliable.")
    return out


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/meta")
def meta():
    fields = []
    for feat in EXPECTED_FEATURES:
        unit, hint = FEATURE_INFO[feat]
        fields.append({"name": feat, "unit": unit, "hint": hint, **RANGES[feat]})
    return jsonify({
        "features": fields,
        "target": METADATA.get("target", "quality"),
        "model": METADATA.get("best_model", "Random Forest"),
        "dataset_rows": DATASET_ROWS,
        "good_threshold": GOOD_THRESHOLD,
        "classes": [int(c) for c in rf_model.classes_],
    })


@app.route("/health")
def health():
    return jsonify({
        "status": "ok",
        "random_forest_loaded": type(rf_model).__name__,
        "model_path": str(RF_MODEL_PATH.relative_to(BASE_DIR)),
        "features": EXPECTED_FEATURES,
    })


@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json(silent=True) or {}
    values = {}
    errors = []
    for feat in EXPECTED_FEATURES:
        raw = data.get(feat)
        try:
            v = float(raw)
            if not np.isfinite(v):
                raise ValueError
            values[feat] = v
        except (TypeError, ValueError):
            errors.append(f"'{feat}' must be a valid number.")
    if errors:
        return jsonify({"error": " ".join(errors)}), 400

    df = pd.DataFrame([values], columns=EXPECTED_FEATURES)
    rf_pred, rf_conf, dt_pred = predict_frame(df)
    score = int(rf_pred[0])
    return jsonify({
        "wine_type": "Red Wine",
        "predicted_quality": score,
        "quality_percentage": quality_percentage(score),
        "category": category(score),
        "model_confidence": round(float(rf_conf[0]) * 100, 1),
        "decision_tree_quality": int(dt_pred[0]),
        "warnings": range_warnings(values),
    })


@app.route("/predict-csv", methods=["POST"])
def predict_csv():
    file = request.files.get("file")
    if file is None or file.filename == "":
        return jsonify({"error": "Please choose a CSV file."}), 400
    try:
        df = pd.read_csv(io.BytesIO(file.read()))
    except Exception:
        return jsonify({"error": "Could not read that file as a CSV."}), 400

    # Match columns ignoring case and surrounding spaces.
    lookup = {str(c).strip().lower(): c for c in df.columns}
    missing = [f for f in EXPECTED_FEATURES if f.lower() not in lookup]
    if missing:
        return jsonify({"error": "Missing column(s): " + ", ".join(missing)}), 400
    if len(df) == 0:
        return jsonify({"error": "The CSV has no rows."}), 400
    if len(df) > MAX_CSV_ROWS:
        return jsonify({"error": f"Please upload at most {MAX_CSV_ROWS} rows."}), 400

    feats = pd.DataFrame({f: pd.to_numeric(df[lookup[f.lower()]], errors="coerce") for f in EXPECTED_FEATURES})
    valid = feats.notna().all(axis=1) & np.isfinite(feats).all(axis=1)

    rows = []
    preds = {}
    if valid.any():
        rf_pred, rf_conf, _ = predict_frame(feats[valid])
        for idx, p, c in zip(feats[valid].index, rf_pred, rf_conf):
            preds[idx] = (int(p), float(c))

    good = 0
    for i in range(len(feats)):
        row = {"row": i + 1}
        if i in preds:
            score, conf = preds[i]
            row.update({
                "predicted_quality": score,
                "quality_percentage": quality_percentage(score),
                "category": category(score),
                "model_confidence": round(conf * 100, 1),
            })
            good += score >= GOOD_THRESHOLD
        else:
            row["error"] = "Missing or non-numeric value"
        rows.append(row)

    return jsonify({
        "wine_type": "Red Wine",
        "total": len(rows),
        "predicted": len(preds),
        "skipped": len(rows) - len(preds),
        "good": int(good),
        "needs_improvement": len(preds) - int(good),
        "rows": rows,
    })


@app.errorhandler(413)
def too_large(_):
    return jsonify({"error": "File too large (limit 2 MB)."}), 413


if __name__ == "__main__":
    print("Random Forest model loaded from:", RF_MODEL_PATH)
    print("Open http://127.0.0.1:5000 in your browser")
    app.run(host="127.0.0.1", port=5000, debug=True, use_reloader=False)
