# Red Wine Quality Prediction

A Flask website that predicts the quality of a red wine from 11 lab measurements.
It uses the **Random Forest** (main model) and **Decision Tree** (comparison) models
trained in Google Colab. The models are used exactly as exported; nothing is retrained.

## Run on Windows (VS Code terminal)

```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:5000

Use Python 3.10 to 3.13. `requirements.txt` pins `scikit-learn==1.6.1`, the same
version used in Colab, so the saved models load without version problems.

## Project structure

```
app.py                                Flask backend
requirements.txt
dataset/winequality-red-project.csv   Training dataset (1,600 red wines)
dataset/sample_upload.csv             10 rows to try the CSV upload
models/random_forest_model.pkl        Main model (from Colab)
models/decision_tree_model.pkl        Comparison model (from Colab)
models/model_metadata.json            Feature list, target, best model
templates/index.html
static/style.css
static/script.js
```

## Model inputs (in this exact order)

fixed acidity, volatile acidity, citric acid, residual sugar, chlorides,
free sulfur dioxide, total sulfur dioxide, density, pH, sulphates, alcohol.
Target: `quality`.

## What the results mean

- **Predicted quality**: the score predicted by the Random Forest (the training data contains scores 4 to 7).
- **Quality percentage**: the predicted score out of 10 shown as a percentage (for example 6 becomes 60%). It is **not** the model's accuracy.
- **Category**: Good if the predicted quality is 6 or higher, otherwise Needs Improvement.
- **Model confidence**: how strongly the Random Forest favoured its predicted score. It is separate from the quality percentage.
- **Wine type**: always Red Wine, because the project uses the red-wine dataset.
- **Model Training Dataset Range**: the minimum and maximum of each feature in the training data. It is not a universal scientific limit. Values outside it are still accepted, but the page warns that the prediction may be less reliable.

## CSV upload

Upload a CSV containing the 11 feature columns (names are matched ignoring case; extra columns such as `quality` are ignored). You can try `dataset/sample_upload.csv`. Results can be downloaded as a CSV.

## Checking the model loaded

With the server running, visit http://127.0.0.1:5000/health. It reports the loaded Random Forest model and its path.
