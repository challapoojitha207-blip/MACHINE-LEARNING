(function () {
  "use strict";

  const GROUPS = [
    ["Acidity", ["fixed acidity", "volatile acidity", "citric acid", "pH"]],
    ["Sugar and salts", ["residual sugar", "chlorides", "sulphates"]],
    ["Sulfur dioxide", ["free sulfur dioxide", "total sulfur dioxide"]],
    ["Body", ["density", "alcohol"]],
  ];

  let META = null;
  let csvRows = [];
  const $ = (id) => document.getElementById(id);
  const idFor = (name) => "f-" + name.replace(/\s+/g, "-");

  function fmt(n) { return Number(n.toPrecision(5)).toString(); }

  function stepFor(f) {
    const span = f.max - f.min;
    if (f.name === "density") return "0.00001";
    if (span > 50) return "0.1";
    if (span > 5) return "0.01";
    return "0.001";
  }

  function buildForm() {
    const byName = Object.fromEntries(META.features.map((f) => [f.name, f]));
    const holder = $("fields");
    GROUPS.forEach(([title, names]) => {
      const sec = document.createElement("section");
      sec.className = "group";
      sec.innerHTML = "<h2></h2><div class='group-grid'></div>";
      sec.querySelector("h2").textContent = title;
      const grid = sec.querySelector(".group-grid");
      names.forEach((n) => {
        const f = byName[n];
        const wrap = document.createElement("div");
        wrap.className = "field";
        const unit = f.unit ? `<span class="unit">${f.unit}</span>` : "";
        wrap.innerHTML =
          `<label for="${idFor(n)}"><span>${n}</span>${unit}</label>` +
          `<input type="number" id="${idFor(n)}" name="${n}" step="${stepFor(f)}" inputmode="decimal" required>` +
          `<p class="hint">${f.hint}</p>` +
          `<p class="range"><b>Model Training Dataset Range:</b> ${fmt(f.min)} to ${fmt(f.max)}</p>`;
        grid.appendChild(wrap);
      });
      holder.appendChild(sec);
    });
    $("foot-model").textContent = META.model;
    $("foot-rows").textContent = META.dataset_rows.toLocaleString();
  }

  function setLevel(pct) {
    // bowl runs from y=20 (rim) to y=160 (bottom): 140 units of height
    const y = 140 - (Math.max(0, Math.min(100, pct)) / 100) * 140 + 0;
    $("liquid").style.transform = `translateY(${y + 20}px)`;
  }

  function showError(el, msg) { el.textContent = msg; el.hidden = !msg; }

  function readValues() {
    const values = {};
    let bad = false;
    META.features.forEach((f) => {
      const input = $(idFor(f.name));
      const v = parseFloat(input.value);
      const ok = input.value.trim() !== "" && Number.isFinite(v);
      input.classList.toggle("invalid", !ok);
      if (!ok) bad = true;
      values[f.name] = v;
    });
    return bad ? null : values;
  }

  async function onSubmit(e) {
    e.preventDefault();
    const err = $("form-error");
    showError(err, "");
    const values = readValues();
    if (!values) { showError(err, "Please enter a number for every property."); return; }
    const btn = $("predict-btn");
    btn.disabled = true;
    try {
      const res = await fetch("/predict", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(values),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Prediction failed.");
      renderResult(data);
    } catch (ex) {
      showError(err, ex.message);
    } finally {
      btn.disabled = false;
    }
  }

  function renderResult(d) {
    $("empty-state").hidden = true;
    $("result").hidden = false;
    $("r-type").textContent = d.wine_type;
    $("r-quality").textContent = d.predicted_quality;
    $("r-pct").textContent = d.quality_percentage + "%";
    $("r-conf").textContent = d.model_confidence + "%";
    const cat = $("r-cat");
    cat.textContent = d.category;
    cat.className = "badge " + (d.category === "Good" ? "good" : "needs");
    $("r-dt").textContent = "Decision Tree comparison model predicts quality " + d.decision_tree_quality + ".";
    const w = $("r-warn");
    w.innerHTML = "";
    d.warnings.forEach((t) => { const li = document.createElement("li"); li.textContent = t; w.appendChild(li); });
    setLevel(d.quality_percentage);
  }

  function resetResult() {
    $("empty-state").hidden = false;
    $("result").hidden = true;
    setLevel(0);
  }

  function fillTypical() {
    META.features.forEach((f) => { $(idFor(f.name)).value = fmt(f.median); $(idFor(f.name)).classList.remove("invalid"); });
    showError($("form-error"), "");
  }

  function clearAll() {
    META.features.forEach((f) => { $(idFor(f.name)).value = ""; $(idFor(f.name)).classList.remove("invalid"); });
    showError($("form-error"), "");
    resetResult();
  }

  async function onCsv() {
    const err = $("csv-error");
    showError(err, "");
    $("csv-result").hidden = true;
    const file = $("csv-file").files[0];
    if (!file) { showError(err, "Please choose a CSV file first."); return; }
    const fd = new FormData();
    fd.append("file", file);
    const btn = $("csv-btn");
    btn.disabled = true;
    try {
      const res = await fetch("/predict-csv", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "CSV prediction failed.");
      renderCsv(data);
    } catch (ex) {
      showError(err, ex.message);
    } finally {
      btn.disabled = false;
    }
  }

  function renderCsv(d) {
    csvRows = d.rows;
    $("csv-summary").textContent =
      `${d.wine_type}: ${d.predicted} of ${d.total} rows predicted. ${d.good} Good, ${d.needs_improvement} Needs Improvement` +
      (d.skipped ? `, ${d.skipped} skipped (missing or non-numeric values).` : ".");
    const body = $("csv-body");
    body.innerHTML = "";
    d.rows.forEach((r) => {
      const tr = document.createElement("tr");
      const cells = r.error
        ? [r.row, r.error, "", "", ""]
        : [r.row, r.predicted_quality, r.quality_percentage + "%", r.category, r.model_confidence + "%"];
      cells.forEach((c) => { const td = document.createElement("td"); td.textContent = c; tr.appendChild(td); });
      body.appendChild(tr);
    });
    $("csv-result").hidden = false;
  }

  function downloadCsv() {
    const lines = ["row,predicted_quality,quality_percentage,category,model_confidence_percent"];
    csvRows.forEach((r) => {
      lines.push(r.error
        ? `${r.row},,,${r.error},`
        : `${r.row},${r.predicted_quality},${r.quality_percentage},${r.category},${r.model_confidence}`);
    });
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "wine_predictions.csv";
    a.click();
    URL.revokeObjectURL(a.href);
  }

  async function init() {
    try {
      const res = await fetch("/api/meta");
      META = await res.json();
    } catch (e) {
      $("fields").textContent = "Could not load model information. Is the Flask server running?";
      return;
    }
    buildForm();
    $("wine-form").addEventListener("submit", onSubmit);
    $("sample-btn").addEventListener("click", fillTypical);
    $("clear-btn").addEventListener("click", clearAll);
    $("csv-btn").addEventListener("click", onCsv);
    $("csv-download").addEventListener("click", downloadCsv);
    setLevel(0);
  }

  init();
})();
